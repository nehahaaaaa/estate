document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const loginMessageDiv = document.getElementById('login-message');

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    const response = await fetch('http://localhost:8000/api/v1/auth/login/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();

    if (response.ok) {
      // Store user information (e.g., token) in localStorage
      localStorage.setItem('token', data.token);  // Assuming you get a token in response
      localStorage.setItem('username', data.username); // Save username or any other info

      // Redirect to the home page
      window.location.href = './index.html';  // Navigate to home page
    } else {
      loginMessageDiv.innerHTML = `<p style="color: red;">${data.message}</p>`;
    }
  });
});
