document.addEventListener('DOMContentLoaded', () => {
  const registerForm = document.getElementById('register-form');
  const registerMessageDiv = document.getElementById('register-message');

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;

    const response = await fetch('http://localhost:8000/api/v1/auth/register/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    console.log(data);
    
    if (response.ok) {
      registerMessageDiv.innerHTML = `<p style="color: green;">${data.message}</p>`;
      
      // Wait for 2 seconds before navigating to login page
      setTimeout(() => {
        window.location.href = './login.html'; // Redirect to login page
      }, 2000); // 2000 milliseconds = 2 seconds

      registerForm.reset();
    } else {
      registerMessageDiv.innerHTML = `<p style="color: red;">${data.message}</p>`;
    }
  });
});
