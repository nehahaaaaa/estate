import mongoose from 'mongoose';

const connectDB = async (url) => {
    try {
        console.log(url);
        
        await mongoose.connect(url);
        console.log('MongoDB connected successfully');
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

export default connectDB;