import User from "../models/userModel.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET;

const registerUser = async (req, res) => {
  const { username, password } = req.body;
  console.log({ username, password });

  try {
    // Check if the user already exists
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user object
    const newUser = new User({
      username,
      password: hashedPassword,
    });

    // Save the new user to the database
    await newUser.save();

    res.status(201).json({ message: "User registered successfully" });
  } catch (err) {
    res.status(500).json({ error: "Failed to register user" });
  }
};


const loginUser = async (req, res) => {
    const { username, password } = req.body;
     
    console.log({username, password});
    
    try {
      // Find the user in the database by username
      const user = await User.findOne({ username });
      
      if (!user) {
        return res.status(404).json({ message: "User does not exist" });  // Return 404 if user is not found
      }
  
      console.log("User found:", user);
      
      // Check if the provided password matches the hashed password in the database
      const isPasswordValid = await bcrypt.compare(password, user.password);
      
      console.log("Is password valid:", isPasswordValid);
      
      if (!isPasswordValid) {
        return res.status(400).json({ message: "Invalid credentials" });  // Return error if password is incorrect
      }
  
      // Generate a JWT token with the username and expiry time
      const token = jwt.sign({ username: user.username }, JWT_SECRET, {
        expiresIn: "1h",
      });
  
      // Return the token and user information to the frontend
      res.status(200).json({
        message: "Login successful",
        token,  // Send the JWT token
        username: user.username,  // Optionally return username for client use
      });
    } catch (err) {
      // Log the error for debugging and return a generic error message
      console.error("Error during login:", err);
      res.status(500).json({ error: "An error occurred during login. Please try again later." });
    }
  };


export { registerUser, loginUser };
