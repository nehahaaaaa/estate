import Property from "../models/propertyModel.js";

const getAllPropertyList = async (req, res) => {
    try {
        const properties = await Property.find({});
        res.json(properties);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch properties' });
    }
}

const addNewPropertyByAdmin = async (req, res) => {
    const { name, price, location } = req.body;
    try {
        const newProperty = new Property({ name, price, location });
        await newProperty.save();
        res.status(201).json(newProperty);
    } catch (err) {
        res.status(500).json({ error: 'Failed to add property' });
    }
}


export {
    getAllPropertyList,
    addNewPropertyByAdmin,
}