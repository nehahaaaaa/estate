import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

import connectDB from './config/db.js';
import propertyRoute from './routes/propertyRoute.js';
import authRoute from './routes/authRoute.js';


const app = express();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
connectDB(process.env.MONGODB_URL);

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Routes
app.use('/api/v1/property', propertyRoute);
app.use('/api/v1/auth', authRoute);

// Serve frontend files
app.use(express.static('client'));

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
