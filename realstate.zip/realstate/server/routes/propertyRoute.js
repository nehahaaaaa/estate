import express from 'express';

import { getAllPropertyList, addNewPropertyByAdmin } from '../controllers/propertyController.js';

const router = express.Router();

// Get all properties
router.get('/', getAllPropertyList);

// Add a new property (Admin feature)
router.post('/add-new', addNewPropertyByAdmin);

export default router;
